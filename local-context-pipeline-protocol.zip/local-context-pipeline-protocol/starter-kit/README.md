# Starter kit

This folder is meant to be copied into an operator-owned store.

The starter kit contains:

- minimal templates for the canonical output set,
- minimal durable registries (entities, style contract, decision log),
- a lightweight boundary policy.

The starter kit is intentionally sparse. The protocol’s invariants do the work; the rest can be invented.

© 2026 Mikhail Shakhnazarov — CC BY-SA 4.0
